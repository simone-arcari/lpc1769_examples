/*
 * HC_SR04.h
 *
 *  Created on: 21 ago 2019
 *      Author: simon
 */

#ifndef HC_SR04_H_
#define HC_SR04_H_


void initTimer2Capture(void);
void initTimer3Match(void);

#endif /* HC_SR04_H_ */
