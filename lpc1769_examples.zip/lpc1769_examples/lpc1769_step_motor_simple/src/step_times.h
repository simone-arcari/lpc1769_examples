/*
 * step_times.h
 *
 *  Created on: 15 dic 2018
 *      Author: nicola
 */

#ifndef STEP_TIMES_H_
#define STEP_TIMES_H_

#define ACC_LEN	400
#define DEC_LEN	400
#define MAX_RUN_LEN 4800



#endif /* STEP_TIMES_H_ */
