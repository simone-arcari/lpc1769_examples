/*
 * display.h
 *
 *  Created on: 10 feb 2019
 *      Author: simon
 */

#ifndef DISPLAY_H_
#define DISPLAY_H_

void setDigits(char digit);
void displayView2Digits(int number);
void displayView3Digits(int number);
void displayView4Digits(int number);

#endif /* DISPLAY_H_ */
